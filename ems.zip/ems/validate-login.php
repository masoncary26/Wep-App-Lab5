<?php
session_start();
$conn = new mysqli("localhost", "root", "", "education_management_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$userid = $_POST['userid'];
$password = $_POST['pwd'];
$_SESSION['id'] = $userid;
		$_SESSION['pwd'] = $password;
	
	$sql = "SELECT role FROM users_tab WHERE userid = '$userid' AND password = '$password'";
    $result = $conn->query($sql);
	$row_users = $result->fetch_assoc();
	$_SESSION['role'] = $row_users['role'];
	
	
	if($_SESSION['role'] == 'S')
		header('Location:student.php');
	
	if($_SESSION['role'] == 'F')
		header('Location:faculty.php');
	
	if($_SESSION['role'] == 'A')
		header('Location:admin.php');
	
?>
